<?php
return [
   "server" => [
       "protocol"  => "smtp",
       "security"  => "tls",
       "host"      => "smtp.gmail.com",
       "port"      => 587,
       "username"  => "your-email@gmail.com",
       "password"  => "your-gmail-password",
       "debug"     => 1
   ],
   "from" => [
       "name"      => "your-name",
       "mail"      => "your-email@gmail.com"
   ],
   "reply" => [
       "name"      => "your-name",
       "mail"      => "your-email@gmail.com"
   ]
];
